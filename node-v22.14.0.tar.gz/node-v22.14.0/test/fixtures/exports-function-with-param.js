module.exports = function foo(arg) { return arg; }
