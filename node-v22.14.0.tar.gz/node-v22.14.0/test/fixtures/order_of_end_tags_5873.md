# Title

## Subsection

### Static method: Buffer.from(array)
* `array` {Array}
