Object.defineProperty(process.env, 'FOO', {
  configurable: true,
  enumerable: true,
  writable: true,
  value: 'FOO',
});
