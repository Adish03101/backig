Object.keys(process.env);

const env = { ...process.env };
