const foo = process.env.FOO;
const bar = process.env.BAR;
