'use strict';

const fs = require('fs');

fs.foo = 'I am from the snapshot';
