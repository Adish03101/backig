throw new Error('some error');
