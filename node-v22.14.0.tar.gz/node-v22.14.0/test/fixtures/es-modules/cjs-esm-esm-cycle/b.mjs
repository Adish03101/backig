import './a.mjs'
export const b = 5;
