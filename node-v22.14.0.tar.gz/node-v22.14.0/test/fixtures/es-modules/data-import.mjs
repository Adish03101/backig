export { default as data } from 'data:text/javascript,export default %7B%20hello%3A%20%22world%22%20%7D';
export const id = 'data:text/javascript,export default %7B%20hello%3A%20%22world%22%20%7D';
