// This file can be run or imported only if `--experimental-default-type=module` is set
// or `--experimental-detect-module` is not disabled. If it's loaded by
// require(), then `--experimental-require-module` must not be disabled.
export default 'module';
console.log('executed');
