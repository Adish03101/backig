console.log('.cjs file');
