export const __esModule = false;
export default { hello: 'world' };
