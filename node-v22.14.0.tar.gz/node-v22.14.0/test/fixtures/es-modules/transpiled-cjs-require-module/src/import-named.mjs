import { log } from 'logger';
log(console, 'import named');
