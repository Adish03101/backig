module.exports = { entry: 'cjs' };
