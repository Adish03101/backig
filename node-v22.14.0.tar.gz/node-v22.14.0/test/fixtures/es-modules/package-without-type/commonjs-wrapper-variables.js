const exports = "exports";
const require = "require";
const module = "module";
const __filename = "__filename";
const __dirname = "__dirname";
console.log(exports, require, module, __filename, __dirname);
