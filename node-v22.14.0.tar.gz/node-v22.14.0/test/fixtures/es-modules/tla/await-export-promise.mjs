import promise from './export-promise.mjs';
let result;
result = await promise;
export default result;
