module.exports = {
  hello: 'world',
};
