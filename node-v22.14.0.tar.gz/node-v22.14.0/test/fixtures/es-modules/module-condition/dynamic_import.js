function load(id) {
  return import(id);
}

export { load as import };
