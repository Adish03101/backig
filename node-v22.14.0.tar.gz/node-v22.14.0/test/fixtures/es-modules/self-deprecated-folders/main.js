import 'self/main.js';
import '#self/main.js';
