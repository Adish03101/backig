'use strict';
module.exports = module.children.slice();
