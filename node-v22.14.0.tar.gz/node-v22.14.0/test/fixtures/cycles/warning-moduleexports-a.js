module.exports = {};
require('./warning-moduleexports-b.js');
