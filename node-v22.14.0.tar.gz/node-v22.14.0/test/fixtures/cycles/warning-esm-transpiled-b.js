require('./warning-esm-transpiled-a.js').missingPropESM;
