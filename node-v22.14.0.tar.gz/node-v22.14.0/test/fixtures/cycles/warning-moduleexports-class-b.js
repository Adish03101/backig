require('./warning-moduleexports-class-a.js').missingPropModuleExportsClassB;
