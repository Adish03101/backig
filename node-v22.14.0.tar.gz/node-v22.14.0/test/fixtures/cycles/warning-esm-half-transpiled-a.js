require('./warning-esm-half-transpiled-b.js');
