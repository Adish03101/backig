const str = "Hello, TypeScript!";
console.log(str);
