import { foo } from './test-export-foo.ts';

interface Foo {};

console.log(foo);
