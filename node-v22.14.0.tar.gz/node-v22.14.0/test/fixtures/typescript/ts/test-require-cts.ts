const { foo } = require('../cts/test-cts-export-foo.cts');

interface Foo {};

console.log(foo);
