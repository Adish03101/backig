import { MyType } from './test-types.d.ts';

const myVar: MyType = {
    foo: 'Hello, TypeScript!'
};

console.log(myVar.foo);
