const util = require('node:util');

const text = 'Hello, TypeScript!';

module.exports = {
    text
};
