const logger = (): void => { };

module.exports = {
    logger
}
