export const foo: string = 'Hello, TypeScript!';
