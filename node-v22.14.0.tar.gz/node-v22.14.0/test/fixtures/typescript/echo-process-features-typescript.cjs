'use strict';
console.log(process.features.typescript);
