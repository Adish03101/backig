'use strict';

require('../../common');

console.log(123, 'foo', { bar: 'baz' });
