console.log('safe to debug now');
setInterval(() => {}, 1000);
